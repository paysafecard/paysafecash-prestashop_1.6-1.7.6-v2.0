<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{paysafecash}prestashop>paysafecash_30bb072092f15a4b05b8a91c63fe2d9a'] = 'Paysafecash';
$_MODULE['<{paysafecash}prestashop>paysafecash_8e15cbfc33103df39416ac733391a58c'] = 'Paysafecash je hotovostní platební metoda. Vygeneruj si QR/čárový kód a zaplať v obchodě ve tvém okolí. Další informace a naše partnerské pobočky najdeš na www.paysafecash.com';

$_MODULE['<{paysafecash}prestashop>confirmation_88526efe38fd18179a127024aba8c1d7'] = 'Vaše objednávka na %s je dokončena.';
$_MODULE['<{paysafecash}prestashop>confirmation_b2f40690858b404ed10e62bdf422c704'] = 'Množství';
$_MODULE['<{paysafecash}prestashop>confirmation_63d5049791d9d79d86e9a108b0a999ca'] = 'Odkaz';
$_MODULE['<{paysafecash}prestashop>confirmation_19c419a8a4f1cd621853376a930a2e24'] = 'E-mail byl odeslán s touto informací.';
$_MODULE['<{paysafecash}prestashop>confirmation_ca7e41a658753c87973936d7ce2429a8'] = 'Máte-li otázky, připomínky nebo obavy, kontaktujte náš odborný';
$_MODULE['<{paysafecash}prestashop>confirmation_cd430c2eb4b87fb3b49320bd21af074e'] = 'tým pro podporu zákazníků.';
$_MODULE['<{paysafecash}prestashop>confirmation_7569ab9b5973795ce8c9fc870d38d8e1'] = 'Vaše žádost o %s nebyl přijat.';
$_MODULE['<{paysafecash}prestashop>confirmation_caa4088f1d295cf8ce8e358eb975ab32'] = 'Prosím, zkuste to znovu objednat.';
$_MODULE['<{paysafecash}prestashop>confirmation_a25c753ee3e4be15ec0daa5a40deb7b8'] = 'Došlo k chybě.';

$_MODULE['<{paysafecash}prestashop>payment_options_8b2afc4da8a75fb2b33529983fd08070'] = 'Plaťte pomocí Paysafecash';
$_MODULE['<{paysafecash}prestashop>payment_options_f270330ff96da91dd9c1f398ae54e781'] = 'Paysafecash ist eine Barzahlungsmethode. Generiere dir einen QR/Barcode und bezahle in einem Shop in deiner Nähe. Mehr Informationen und unsere Partnerfilialen findest du auf ';

$_MODULE['<{paysafecash}prestashop>paysafecash_info_88526efe38fd18179a127024aba8c1d7'] = 'Vaše objednávka na %s je dokončena.';
$_MODULE['<{paysafecash}prestashop>paysafecash_info_b2f40690858b404ed10e62bdf422c704'] = 'Množství';
$_MODULE['<{paysafecash}prestashop>paysafecash_info_63d5049791d9d79d86e9a108b0a999ca'] = 'Odkaz';
$_MODULE['<{paysafecash}prestashop>paysafecash_info_19c419a8a4f1cd621853376a930a2e24'] = 'E-mail byl odeslán s touto informací.';
$_MODULE['<{paysafecash}prestashop>paysafecash_info_ca7e41a658753c87973936d7ce2429a8'] = 'Máte-li otázky, připomínky nebo obavy, kontaktujte náš odborný';
$_MODULE['<{paysafecash}prestashop>paysafecash_info_cd430c2eb4b87fb3b49320bd21af074e'] = 'tým pro podporu zákazníků.';
$_MODULE['<{paysafecash}prestashop>paysafecash_info_7569ab9b5973795ce8c9fc870d38d8e1'] = 'Vaše žádost o %s nebyl přijat.';
$_MODULE['<{paysafecash}prestashop>paysafecash_info_caa4088f1d295cf8ce8e358eb975ab32'] = 'Prosím, zkuste to znovu objednat.';

