<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{paysafecash}prestashop>paysafecash_30bb072092f15a4b05b8a91c63fe2d9a'] = 'Paysafecash';
$_MODULE['<{paysafecash}prestashop>paysafecash_8e15cbfc33103df39416ac733391a58c'] = 'Paysafecash é um meio de pagamento em dinheiro. Gera um QR/código de barras e paga numa loja da tua conveniência.  Podes encontrar mais informações, bem como as filiais com que temos parceria em www.paysafecash.com';

$_MODULE['<{paysafecash}prestashop>confirmation_88526efe38fd18179a127024aba8c1d7'] = 'Seu pedido on %s está completo.';
$_MODULE['<{paysafecash}prestashop>confirmation_b2f40690858b404ed10e62bdf422c704'] = 'Montante';
$_MODULE['<{paysafecash}prestashop>confirmation_63d5049791d9d79d86e9a108b0a999ca'] = 'Referência';
$_MODULE['<{paysafecash}prestashop>confirmation_19c419a8a4f1cd621853376a930a2e24'] = 'Um email foi enviado com esta informação.';
$_MODULE['<{paysafecash}prestashop>confirmation_ca7e41a658753c87973936d7ce2429a8'] = 'Se você tiver perguntas, comentários ou preocupações, entre em contato com nossa';
$_MODULE['<{paysafecash}prestashop>confirmation_cd430c2eb4b87fb3b49320bd21af074e'] = 'equipe de suporte ao cliente especialista.';
$_MODULE['<{paysafecash}prestashop>confirmation_7569ab9b5973795ce8c9fc870d38d8e1'] = 'Seu pedido on %s não foi aceite.';
$_MODULE['<{paysafecash}prestashop>confirmation_caa4088f1d295cf8ce8e358eb975ab32'] = 'Por favor, tente solicitar novamente.';
$_MODULE['<{paysafecash}prestashop>confirmation_a25c753ee3e4be15ec0daa5a40deb7b8'] = 'Ocorreu um erro.';

$_MODULE['<{paysafecash}prestashop>payment_options_8b2afc4da8a75fb2b33529983fd08070'] = 'Pague com Paysafecash';
$_MODULE['<{paysafecash}prestashop>payment_options_f270330ff96da91dd9c1f398ae54e781'] = 'Paysafecash é um meio de pagamento em dinheiro. Gera um QR/código de barras e paga numa loja da tua conveniência.  Podes encontrar mais informações, bem como as filiais com que temos parceria em www.paysafecash.com';

$_MODULE['<{paysafecash}prestashop>paysafecash_info_88526efe38fd18179a127024aba8c1d7'] = 'Seu pedido on %s está completo.';
$_MODULE['<{paysafecash}prestashop>paysafecash_info_b2f40690858b404ed10e62bdf422c704'] = 'Montante';
$_MODULE['<{paysafecash}prestashop>paysafecash_info_63d5049791d9d79d86e9a108b0a999ca'] = 'Referência';
$_MODULE['<{paysafecash}prestashop>paysafecash_info_19c419a8a4f1cd621853376a930a2e24'] = 'Um email foi enviado com esta informação.';
$_MODULE['<{paysafecash}prestashop>paysafecash_info_ca7e41a658753c87973936d7ce2429a8'] = 'Se você tiver perguntas, comentários ou preocupações, entre em contato com nossa';
$_MODULE['<{paysafecash}prestashop>paysafecash_info_cd430c2eb4b87fb3b49320bd21af074e'] = 'equipe de suporte ao cliente especialista.';
$_MODULE['<{paysafecash}prestashop>paysafecash_info_7569ab9b5973795ce8c9fc870d38d8e1'] = 'Seu pedido on %s não foi aceite.';
$_MODULE['<{paysafecash}prestashop>paysafecash_info_caa4088f1d295cf8ce8e358eb975ab32'] = 'Por favor, tente solicitar novamente.';

