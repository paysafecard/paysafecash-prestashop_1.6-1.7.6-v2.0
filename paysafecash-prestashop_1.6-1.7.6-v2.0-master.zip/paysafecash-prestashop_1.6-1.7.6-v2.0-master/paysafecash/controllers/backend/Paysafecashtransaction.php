<?php
use PrestaShopBundle\Controller\Admin\FrameworkBundleAdminController;

class AdminPaysafecashTransactionsController extends ModuleAdminControllerCore
{
    public function getContent()
    {
        echo "Test";
        //return $this->display(__FILE__, 'views/templates/admin/transactions.tpl');
    }
}